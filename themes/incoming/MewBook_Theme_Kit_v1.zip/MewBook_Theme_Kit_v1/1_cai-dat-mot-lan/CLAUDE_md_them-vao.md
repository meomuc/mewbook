## Theme (giao diện màu) — chuẩn gói theme v1

Mọi theme của MewBook là DỮ LIỆU, không phải mã. Mỗi theme nằm trong
`themes/<id>/theme.json` (+ `fonts/`, `preview/` nếu có) và tuân theo
`themes/_schema/theme.schema.json`. Không viết mã màu trực tiếp trong widget,
QSS hay delegate: mọi màu lấy từ ThemeManager.

### Cấu trúc thư mục
```
themes/
  _schema/theme.schema.json      # chuẩn dữ liệu (không sửa tay nếu chưa hỏi chủ dự án)
  _schema/validate_theme.py      # bộ kiểm tra, dùng cả trong test
  incoming/                      # nơi chủ dự án bỏ gói mewbook-theme-*.zip
  incoming/_da-nhap/             # gói đã nhập xong được chuyển vào đây
  <id>/theme.json                # mỗi theme một thư mục
  <id>/fonts/  <id>/preview/
styles/base.qss.tpl              # QSS mẫu dùng $token
```

### Khi chủ dự án nói "Nhập theme mới trong themes/incoming"
Làm đúng các bước, không hỏi lại trừ khi có LỖI:
1. Với mỗi `themes/incoming/mewbook-theme-*.zip`: chạy
   `python themes/_schema/validate_theme.py <file.zip>`.
   - Mã thoát 1 (LỖI) → KHÔNG nhập, báo nguyên văn danh sách lỗi, dừng gói đó.
   - Mã thoát 0 → tiếp tục; ghi lại các CẢNH BÁO để báo cuối cùng.
2. Giải nén vào `themes/<id>/` (id lấy trong theme.json). Nếu đã có thư mục
   cùng id: so `version`; bản mới hơn thì thay, bằng hoặc cũ hơn thì hỏi.
3. Phông kèm gói (`fonts/*.ttf|otf`): đăng ký bằng
   `QFontDatabase.addApplicationFont` lúc ThemeManager nạp theme. Không cài
   phông vào Windows.
4. `ornaments`: nếu gói dùng một kiểu trang trí CHƯA được cài (xem bảng dưới),
   cài kiểu đó MỘT LẦN, dạng dùng chung, điều khiển hoàn toàn bằng tham số
   trong theme.json. Tuyệt đối không viết `if theme.id == ...`.
5. Theme tự hiện trong Cài đặt › Giao diện (ThemeManager quét `themes/*/`),
   thẻ theme vẽ từ token: nền bg, 3 "cuốn sách" accent / ink / surface2, vạch
   kệ shelf, tên + description + "Nền sáng/tối".
6. Chạy toàn bộ test (bao gồm `tests/test_themes.py`), rồi chụp cửa sổ chính,
   hộp thoại Tìm thông tin sách, Cài đặt › Giao diện ở theme mới; đặt cạnh ảnh
   trong `preview/` và nêu chỗ khác biệt đáng kể.
7. Chuyển file zip vào `themes/incoming/_da-nhap/`.
8. Báo lại ngắn: tên theme, đạt/không, cảnh báo, kiểu trang trí mới đã cài,
   file đã sửa.

### Các kiểu trang trí (ornaments) — cài một lần, dùng chung
| Khối        | Kiểu         | Ý nghĩa khi vẽ |
|-------------|--------------|----------------|
| shelf       | flat         | vạch kệ gradient shelftop → shelf, dày `thickness` (mặc định 6) |
| shelf       | wood         | như flat nhưng có dải sáng ở mặt trên (28%), thân shelf, mép dưới `edge`, vân gỗ `grain` mờ chạy ngang |
| shelf       | glass        | vạch mờ trong suốt 60% + đường sáng 1px ở trên |
| shelf       | brackets     | 2 ke đỡ 7×11 px màu `bracket_color`, cách hai đầu kệ 18 px |
| frame       | wood         | nhãn nhóm thanh bên, header panel chi tiết, tiêu đề cột Cài đặt: nền gradient `light`→`dark`, viền `dark`, chữ `ink` |
| notice      | chalkboard   | thẻ thông báo (tóm tắt nhập, có bản mới, dải mất file): nền `bg`, chữ `ink`, viền dày 7 px màu `frame` |
| cover_frame | wood / line  | khung quanh bìa lớn ở panel chi tiết, dày `width` px |
Thiếu khối nào = dùng kiểu mặc định phẳng. Kiểu không nhận ra = bỏ qua + cảnh báo, không làm vỡ giao diện.

### Quy tắc không được phá (validator kiểm tra tự động)
- ink, ink2 trên bg/rail/panel/surface/surface2 ≥ 4.5:1; ink trên accentsoft ≥ 4.5:1.
- accentink trên accent ≥ 4.5:1; accent (liên kết) trên panel/surface ≥ 4.5:1; accent trên bg ≥ 3:1.
- ok, warn, err trên panel/surface/rail ≥ 3:1; ok/warn/err/accent khác nhau ΔE ≥ 20.
- `dark` phải khớp độ sáng thật của bg.
- Phông kèm gói phải có giấy phép OFL hoặc Apache 2.0 và đủ dấu tiếng Việt.
- Trạng thái luôn có hình dạng/chữ đi kèm, không bao giờ chỉ bằng màu.

### Test bắt buộc: tests/test_themes.py
- Mọi `themes/*/theme.json` qua validate_theme (mã thoát 0).
- ThemeManager nạp được từng theme, sinh QSS không còn `$token` nào chưa thay.
- Đổi theme lúc chạy phát `themeChanged` và các delegate vẽ lại.
